from datetime import time
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from core.models import *

DEMO_PASSWORD = "Demo@12345"  # somente demonstração


class Command(BaseCommand):
    help = "Cria dados de demonstração (bloqueado com DEBUG=0 sem --force)."
    def add_arguments(self, p): p.add_argument("--force", action="store_true")
    def handle(self, *a, **o):
        if not settings.DEBUG and not o["force"]: raise CommandError("Recusado fora de desenvolvimento.")
        mk = lambda email, name, role: User.objects.get_or_create(email=email, defaults=dict(
            username=email, first_name=name, role=role))[0]
        for u in (mk("gestor@demo.com", "Gestor Demo", "manager"), mk("coord@demo.com", "Coordenadora Demo", "coordinator"),
                  mk("prof@demo.com", "Professor Demo", "professor")):
            u.set_password(DEMO_PASSWORD); u.save()
        c, _ = Course.objects.get_or_create(code="SI", defaults=dict(name="Sistemas de Informação", coordinator=User.objects.get(email="coord@demo.com")))
        s1, _ = Subject.objects.get_or_create(code="BD1", defaults=dict(name="Banco de Dados", course=c, weekly_lessons=2))
        Subject.objects.get_or_create(code="ES1", defaults=dict(name="Engenharia de Software", course=c, weekly_lessons=2))
        p, _ = Professor.objects.get_or_create(user=User.objects.get(email="prof@demo.com"), defaults=dict(max_weekly_hours=16))
        p.subjects.add(s1)
        for r, cap in (("Sala 101", 40), ("Lab 1", 25)): Room.objects.get_or_create(name=r, defaults=dict(capacity=cap))
        for d in range(5):
            for a, b in ((time(8), time(9, 40)), (time(10), time(11, 40)), (time(14), time(15, 40))):
                Slot.objects.get_or_create(weekday=d, start=a, end=b)
        self.stdout.write(f"OK. Logins: gestor@demo.com / coord@demo.com / prof@demo.com — senha {DEMO_PASSWORD}")
