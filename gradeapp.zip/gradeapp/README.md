# Grade Acadêmica — Fase 1 (API + front-end dos 3 perfis)
## Rodar
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py seed_demo        # só em DEBUG; senha demo: Demo@12345
    python manage.py runserver        # abre http://127.0.0.1:8000/
Logins demo: gestor@demo.com, coord@demo.com, prof@demo.com
Para criar o gestor real: `python manage.py shell` → User.objects.create_user(username=e, email=e, password=..., role="manager")
## Testes
    python manage.py test
## Produção
DJANGO_DEBUG=0, DJANGO_SECRET_KEY e ALLOWED_HOSTS obrigatórios (Postgres/HTTPS a configurar).
## Decisões
- Desativar = PATCH {is_active:false}; excluir = DELETE (definitivo). Curso com disciplinas não pode ser excluído (409).
- Tela de Alocação é uma prévia visual (motor real ainda não implementado).
- "Restrições" = disponibilidade semanal (Availability) + carga máxima do professor.
- Token DRF; permissões por perfil no servidor (core/views.py: RolePerm).
